 <!-- Begin Page Content -->
 <div class="container-fluid h-100">

<!-- Page Heading -->
<h1 class="h3 mb-5 text-gray-800"> <?= $judul; ?></h1>

<!-- /.container-fluid -->

<!-- End of Main Content -->
